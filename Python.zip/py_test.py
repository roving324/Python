print("Hello Python!!")
