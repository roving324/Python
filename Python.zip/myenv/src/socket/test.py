import sys

def test(port = sys.argv[1]):
	print(port, int(port))

if __name__ == "__main__":
	test()
